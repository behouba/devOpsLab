# Best pratices
- Use .gitignore to ensure that certain files we don't want to be tracked by Git remain untracked
- Python virtual environment for dependency management and project isolation
- The only route of the project is tested to ensure that it work properly