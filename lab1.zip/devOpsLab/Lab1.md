# 1

## Web application

1. Create `app_python` folder for your application and PYTHON.md inside.
2. Develop and test a simple Python web application, that shows current time in Moscow.
> Research and use best practices and prod ready frameworks. Use linters for Python and Markdown. Don't forget to test it, time must be updated with a page refreshing.
3. Update a PYTHON.md file and describe all best practices that you could find. 
4. Remove content of README.md file with rules for the course and describe your application instead. Description should be in Markdown format.
> Research and use any good template that you like.
## Bonus

1. Create `app_*` folder in the main project, replace `*` with language that you choose (not python). Put new `*`.md inside that folder.
2. Create your own web app, it's up to you what it will show or do, use your imagination.
3. Follow all suggestions and steps from the main task. 
